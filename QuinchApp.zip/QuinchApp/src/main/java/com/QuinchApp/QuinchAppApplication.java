package com.QuinchApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuinchAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuinchAppApplication.class, args);
	}

}
