package com.QuinchApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuinchAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
